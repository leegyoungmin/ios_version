//
//  UserBaseViewController.swift
//  Salud0.2
//
//  Created by 이경민 on 2021/11/19.
//

import Foundation
import UIKit

final class UserBaseViewController:UIViewController{
    let firstTab = UINavigationController(rootViewController: UserMainviewController())
    let secondTab = UINavigationController(rootViewController: UserJournalViewController())
    let thirdTab = UINavigationController(rootViewController: UserStretchingViewController())
    let fourthTab = UINavigationController(rootViewController: UserExerciseViewController())
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        setUpNavigationView()
        setUpView()
    }
    
    func setUpView(){
        
        firstTab.title = "홈"
        secondTab.title = "일지"
        thirdTab.title = "스트레칭"
        fourthTab.title = "코칭"
        
        let tabController = UITabBarController()
        tabController.setViewControllers([firstTab,secondTab,thirdTab,fourthTab], animated: true)
        tabController.modalPresentationStyle = .fullScreen
        present(tabController, animated: false)
    }
    
//    func setUpNavigationView(){
////        let navigationcontroller = UINavigationController()
//        navigationItem.title = "스트레칭"
//        navigationController?.navigationBar.prefersLargeTitles = true
//        navigationItem.largeTitleDisplayMode = .automatic
//    }

}
