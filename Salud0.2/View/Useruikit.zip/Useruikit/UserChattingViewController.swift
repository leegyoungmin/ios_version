//
//  UserChattingViewController.swift
//  Salud0.2
//
//  Created by 이경민 on 2021/11/18.
//

import Foundation
import UIKit
import SnapKit

final class UserChattingViewController:UIViewController{

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigationBar()
        swipeRecognizer()
    }

    func setupNavigationBar(){
        self.navigationController?.interactivePopGestureRecognizer?.delegate = nil
        navigationItem.title = "채팅방"
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "chevron.backward"), style: .done, target: self, action: #selector(didTapBackButton))
        tabBarController?.tabBar.isHidden = true
    }
    
    @objc func didTapBackButton(){
        navigationController?.popViewController(animated: true)
        tabBarController?.tabBar.isHidden = false
    }
    
}

extension UserChattingViewController{
    func swipeRecognizer(){
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(DidSwipeRight(_:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    @objc func DidSwipeRight(_ gesture:UIGestureRecognizer){
        if let swipeGesture = gesture as? UISwipeGestureRecognizer{
            print("swipeRight Gesture Called")
            switch swipeGesture.direction{
            case UISwipeGestureRecognizer.Direction.right:
                didTapBackButton()
            default:
                break
            }
        }
    }
}
