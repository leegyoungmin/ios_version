//
//  UserExerciseViewController.swift
//  Salud0.2
//
//  Created by 이경민 on 2021/11/19.
//

import Foundation
import UIKit

final class UserExerciseViewController:UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "코칭"
        navigationController?.navigationBar.prefersLargeTitles = true
    }
}
