//
//  UserJournalViewController.swift
//  Salud0.2
//
//  Created by 이경민 on 2021/11/19.
//

import Foundation
import UIKit

final class UserJournalViewController:UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigationView()
    }
    
    private func setupNavigationView(){
        let chattingitem = UIBarButtonItem(image: UIImage(systemName: "message.fill"), style: .plain, target: self, action: #selector(presentChattingRoom))
        navigationItem.rightBarButtonItem = chattingitem
        navigationItem.title = "일지"
        navigationController?.navigationBar.prefersLargeTitles = true
    }
    @objc func presentChattingRoom(){
        self.navigationController?.pushViewController(UserChattingViewController(), animated: true)
    }
}
