//
//  UserMainViewController.swift
//  Salud0.2
//
//  Created by 이경민 on 2021/11/19.
//

import Foundation
import UIKit

final class UserMainviewController:UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        navigationItem.title = "홈"
        navigationController?.navigationBar.prefersLargeTitles = true
    }
}
